package ufrpe.negocio.exception;

public class LoginInvalidoExecption extends NegocioException{
	public LoginInvalidoExecption(String mensagem) {
		super(mensagem);
	}
	
}
