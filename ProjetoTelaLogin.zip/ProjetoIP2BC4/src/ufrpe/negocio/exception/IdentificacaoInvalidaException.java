package ufrpe.negocio.exception;

public class IdentificacaoInvalidaException extends NegocioException{

	public IdentificacaoInvalidaException(String mensagem) {
		super(mensagem);
	}

}
