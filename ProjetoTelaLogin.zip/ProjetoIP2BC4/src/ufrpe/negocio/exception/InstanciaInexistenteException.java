package ufrpe.negocio.exception;

public class InstanciaInexistenteException extends NegocioException{

	public InstanciaInexistenteException(String mensagem) {
		super(mensagem);
	}
	
}
