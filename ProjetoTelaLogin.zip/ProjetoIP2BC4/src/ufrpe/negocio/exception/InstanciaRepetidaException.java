package ufrpe.negocio.exception;

public class InstanciaRepetidaException extends NegocioException{

	public InstanciaRepetidaException(String mensagem) {
		super(mensagem);
	}
	
}
