package ufrpe.negocio.exception;

public class QuantidadeInvalidaException extends NegocioException{

	public QuantidadeInvalidaException(String mensagem) {
		super(mensagem);
	}
	
}
