package ufrpe.negocio.exception;

public class NegocioException extends Exception {
	
	public NegocioException(String mensagem){
		super(mensagem);
	}
}
