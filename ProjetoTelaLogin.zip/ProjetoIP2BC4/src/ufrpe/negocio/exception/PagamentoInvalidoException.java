package ufrpe.negocio.exception;

public class PagamentoInvalidoException extends NegocioException{

	public PagamentoInvalidoException(String mensagem) {
		super(mensagem);
	}
	
}
